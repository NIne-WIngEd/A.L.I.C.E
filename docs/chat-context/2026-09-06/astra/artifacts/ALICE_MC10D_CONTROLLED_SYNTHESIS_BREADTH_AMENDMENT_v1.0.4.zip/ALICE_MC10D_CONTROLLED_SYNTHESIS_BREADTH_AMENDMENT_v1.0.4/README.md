# A.L.I.C.E. MC10D Controlled Synthesis Breadth Amendment v1.0.4

Governance-only. This package does not run candidates, judges, pointwise screening, A-SYN acceptance/promotion, or model training.

## Execution prerequisite

v1.0.4 requires a successful MC10D public-judge qualification rebase **v1.8.6**. It verifies the exact v1.8.6 receipt and pointwise-ready bundle hash. It also requires the ratified GLM `thinking_off` profile receipt and effective GLM policy from v1.8.6.

It cannot be ratified before v1.8.6 succeeds.

## Breadth policy

- future high-impact A-SYN generation floor: 3 independent E0 families;
- 4+ E0 families remains the strong-anchor tier;
- 41 previously held three-family high-impact packets reopen only for a future expansion frontier;
- the current 287-candidate MC10D pool remains unchanged;
- behavioral outliers trigger extra challenge rather than automatic rejection;
- noncritical uncertainty may narrow scope, lower tier, remain shadow-only, or defer instead of being deleted;
- repairable scope/role/context defects require a new candidate ID and full retest;
- all 18 falsification tests remain;
- all 8 zero-tolerance provenance/reality gates remain;
- E-INF historical inference policy remains strict;
- synthetic material cannot increase historical Elaina truth confidence;
- no training-authority ratio is changed here.

Amendment SHA-256: `F461D36374A4B1DCD76FB0F5D1346104140AA1BC3AA510E88F04CFBF30A3CBFC`
