from __future__ import annotations
import argparse,hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path
MAIN='0abaed85873c3f8de04765847eb7700b0e20433f'
FREEZE='22B0ADBCCF442B0B3654F964E35AB77A044AF7623891E2A60C72B06A94ECE9A3'
CLAR_RECEIPT='DB7649C0B340191537688FA336A7080B97D6935B01DF4171AAB314E2A15D3015'
SC_RECEIPT='FD1228D88F7F7B7498F70F9DB7595A042E94D8293F19D156C5A970C06B775BF5'
PROFILE_RECEIPT='5A02C0A7035CC5AC0E1638CB04E42A238A5C61A97E1AE3A9C0CDEA4E6B231AC9'
EFFECTIVE_POLICY='45C66A55D5A04162B6373B7FAA7F025CC523945E64E98C1301240E93D91F7F6A'
A_SHA='F461D36374A4B1DCD76FB0F5D1346104140AA1BC3AA510E88F04CFBF30A3CBFC'
DATASET_REL=Path('datasets')/'memory_stage_g2'/'alice.stage-g2.g2a.gold-semantic-decomposition.v1'
CLAR_INSTALL='alice-mc10d-public-judge-source-target-clarification-amendment-v1'
SC_INSTALL='alice-mc10d-public-judge-decision-scoring-amendment-v1'
INSTALL='alice-mc10d-controlled-synthesis-breadth-amendment-v1-0-4'
class Stop(RuntimeError):pass
def req(c,m):
 if not c:raise Stop(m)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest().upper()
def rj(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def wj(p,o):Path(p).write_text(json.dumps(o,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
def git(repo,*args):
 cp=subprocess.run(['git','-C',str(repo),*args],text=True,capture_output=True);req(cp.returncode==0,'git failed: '+(cp.stderr or cp.stdout).strip());return cp.stdout.strip()
def dh(root):return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repo-root',default=r'C:\A.L.I.C.E-main');ap.add_argument('--vault-root',default=r'C:\ALICE_Vault');ap.add_argument('--freeze-bundle',required=True);ap.add_argument('--owner-ratify',action='store_true');a=ap.parse_args();req(a.owner_ratify,'owner ratification flag required');pkg=Path(__file__).resolve().parent;repo=Path(a.repo_root);vault=Path(a.vault_root);freeze=Path(a.freeze_bundle)
 req(git(repo,'rev-parse','--abbrev-ref','HEAD')=='main','not on main');req(git(repo,'rev-parse','HEAD')==MAIN,'main SHA drift');req(git(repo,'status','--porcelain')=='','canonical main working tree not clean');req(freeze.is_file() and sha(freeze)==FREEZE,'freeze hash');req(sha(pkg/'MC10D_CONTROLLED_SYNTHESIS_BREADTH_AMENDMENT_V1_0_4.json')==A_SHA,'amendment hash')
 clar=vault/DATASET_REL/'audits'/CLAR_INSTALL/'RATIFICATION_RECEIPT.json';req(clar.is_file() and sha(clar)==CLAR_RECEIPT,'source-target clarification ratification missing/drift');sc=vault/DATASET_REL/'audits'/SC_INSTALL/'RATIFICATION_RECEIPT.json';req(sc.is_file() and sha(sc)==SC_RECEIPT,'decision scoring ratification missing/drift')
 rp=vault/'tools'/'rayan-compute'/'mc10d'/'public-judge-qualification-rebase-v1.8.6-receipt.json';req(rp.is_file(),'v1.8.6 qualification receipt missing; complete v1.8.6 first');vr=rj(rp);req(vr.get('artifact_id')=='alice.MC10D.public-judge-qualification-rebase.receipt.v1.8.6','v1.8.6 receipt id');req(vr.get('decision_scoring_ratification_receipt_sha256')==SC_RECEIPT,'v1.8.6 scoring binding');req(vr.get('glm_profile_ratification_receipt_sha256')==PROFILE_RECEIPT and vr.get('effective_glm_policy_sha256')==EFFECTIVE_POLICY,'v1.8.6 GLM profile binding')
 qr=vr.get('qualification_results') or {};req(set(qr)=={'gemma','glm'},'v1.8.6 qualification families');req(qr['gemma'].get('reused_v182_rows') is True and qr['glm'].get('reused_v182_rows') is False and qr['glm'].get('qualified_profile')=={'id':'thinking_off','think':False},'Gemma/GLM execution provenance and GLM profile');req(vr.get('effective_pool')==287 and vr.get('deferred_slots')==1 and vr.get('pointwise_screen_started') is False and vr.get('A_SYN_accepted')==0 and vr.get('A_SYN_promoted')==0 and vr.get('model_training') is False,'v1.8.6 boundary')
 ready=Path.home()/'Downloads'/'ALICE_MC10D_POINTWISE_READY_BUNDLE_v1.8.6.zip';req(ready.is_file() and sha(ready)==vr.get('pointwise_ready_bundle_sha256'),'v1.8.6 pointwise-ready bundle missing/hash drift')
 with zipfile.ZipFile(ready) as z:req(z.testzip() is None,'v1.8.6 pointwise-ready ZIP CRC')
 A=rj(pkg/'MC10D_CONTROLLED_SYNTHESIS_BREADTH_AMENDMENT_V1_0_4.json');req(A['current_mc10d_pool']['effective_candidates']==287 and A['current_mc10d_pool']['current_pool_mutated_by_this_amendment'] is False,'current pool boundary');req(A['authority_ceiling']['A_SYN_acceptance_granted'] is False and A['authority_ceiling']['model_training_granted'] is False,'authority ceiling')
 install=vault/DATASET_REL/'audits'/INSTALL;stage=install.with_name(INSTALL+'.staging');shutil.rmtree(stage,ignore_errors=True);stage.mkdir(parents=True);shutil.copy2(pkg/'MC10D_CONTROLLED_SYNTHESIS_BREADTH_AMENDMENT_V1_0_4.json',stage/'MC10D_CONTROLLED_SYNTHESIS_BREADTH_AMENDMENT_V1_0_4.json');shutil.copytree(pkg/'authority',stage/'authority')
 receipt={'artifact_id':'alice.MC10D.controlled-synthesis-breadth-ratification-receipt.v1.0.4','owner_ratified':True,'canonical_main':MAIN,'freeze_sha256':FREEZE,'source_target_clarification_ratification_receipt_sha256':CLAR_RECEIPT,'decision_scoring_ratification_receipt_sha256':SC_RECEIPT,'glm_profile_ratification_receipt_sha256':PROFILE_RECEIPT,'effective_glm_policy_sha256':EFFECTIVE_POLICY,'qualification_rebase_v186_receipt_sha256':sha(rp),'pointwise_ready_bundle_sha256':sha(ready),'current_effective_pool':287,'current_pool_mutated':False,'high_impact_ASYN_E0_family_floor':3,'strong_anchor_E0_family_floor':4,'held_three_family_packets_reopened_for_future_generation':41,'outlier_0975_is_challenge_trigger_not_auto_reject':True,'noncritical_uncertainty_is_narrow_or_lower_tier_or_shadow_or_defer':True,'repairable_candidate_new_id_full_retest':True,'zero_tolerance_gates_unchanged':8,'falsification_tests_unchanged':18,'E_INF_historical_policy_unchanged':True,'synthetic_truth_laundering_forbidden':True,'A_SYN_acceptance_granted':False,'A_SYN_promotion_granted':False,'model_training_granted':False,'pointwise_screen_started':False,'stage_g_closed':False,'phase2_replaced':False,'next_action':'MC10D_POINTWISE_SCOPE_SCREEN_CURRENT_287_USING_CONTROLLED_BREADTH_RETENTION_RULES'};wj(stage/'RATIFICATION_RECEIPT.json',receipt);wj(stage/'MANIFEST.json',{'artifact_id':'alice.MC10D.controlled-synthesis-breadth-installed-manifest.v1.0.4','files':dh(stage)})
 if install.exists():
  req(dh(install)==dh(stage),'existing breadth v1.0.4 installation differs');shutil.rmtree(stage);print('controlled_synthesis_breadth_v104_already_installed_identical=true')
 else:stage.replace(install)
 print('mc10d_controlled_synthesis_breadth_v104_ratified=true');print('owner_ratified=true');print('v186_success_boundary_bound=true');print('glm_profile_amendment_bound=true think=false');print('high_impact_ASYN_E0_family_floor=3 strong_anchor=4');print('held_three_family_future_packets_reopened=41');print('current_effective_pool_unchanged=287');print('outlier_0975_is_challenge_trigger_not_auto_reject=true');print('zero_tolerance_gates_unchanged=8');print('E_INF_historical_policy_unchanged=true');print('A_SYN_acceptance=false A_SYN_promotion=false model_training=false pointwise_screen=false stage_g_closed=false phase2_replaced=false');print('next_action=MC10D_POINTWISE_SCOPE_SCREEN_CURRENT_287_USING_CONTROLLED_BREADTH_RETENTION_RULES');return 0
if __name__=='__main__':
 try:raise SystemExit(main())
 except Stop as e:print('MC10D_CONTROLLED_SYNTHESIS_BREADTH_V104_STOP: '+str(e),file=sys.stderr);raise SystemExit(76)
