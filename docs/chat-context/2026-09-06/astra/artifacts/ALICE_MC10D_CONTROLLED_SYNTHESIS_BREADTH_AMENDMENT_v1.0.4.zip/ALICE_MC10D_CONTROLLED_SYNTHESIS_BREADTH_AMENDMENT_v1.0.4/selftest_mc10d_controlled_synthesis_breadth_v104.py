from pathlib import Path
import hashlib,subprocess,sys,json
R=Path(__file__).resolve().parent
def s(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert s(R/'MC10D_CONTROLLED_SYNTHESIS_BREADTH_AMENDMENT_V1_0_4.json')=='F461D36374A4B1DCD76FB0F5D1346104140AA1BC3AA510E88F04CFBF30A3CBFC'
for f in R.rglob('*.py'):compile(f.read_text(encoding='utf-8'),str(f),'exec')
cp=subprocess.run([sys.executable,str(R/'validate_mc10d_controlled_synthesis_breadth_v104.py'),str(R)],text=True,capture_output=True);print(cp.stdout,end='');assert cp.returncode==0,cp.stderr
t=(R/'mc10d_controlled_synthesis_breadth_controller_v104.py').read_text(encoding='utf-8')
for bad in ['kernels push','datasets create','sbatch','ssh ','scp ']:assert bad not in t.lower(),bad
assert 'public-judge-qualification-rebase-v1.8.6-receipt.json' in t
assert 'ALICE_MC10D_POINTWISE_READY_BUNDLE_v1.8.6.zip' in t
assert '5A02C0A7035CC5AC0E1638CB04E42A238A5C61A97E1AE3A9C0CDEA4E6B231AC9' in t
assert '45C66A55D5A04162B6373B7FAA7F025CC523945E64E98C1301240E93D91F7F6A' in t
assert 'v1.8.5-receipt' not in t and 'v1.8.3-receipt' not in t
print('requires_v186_pointwise_bundle_hash_match=true')
print('remote_execution_absent=true')
print('scientific_candidate_execution_absent=true')
print('mc10d_controlled_synthesis_breadth_v104_selftest_passed=true')
